package actors;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import akka.actor.AbstractActor;
import akka.actor.Actor;
import akka.actor.ActorRef;
import akka.actor.Props;
import akka.actor.AbstractActor.Receive;
import akka.actor.AbstractActorWithTimers;
import akka.event.LoggingAdapter;
import controllers.HomeController;
import play.libs.Json;
import twitter.SearchResults;
import twitter.Twitter;
import twitter4j.QueryResult;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import static akka.pattern.PatternsCS.ask;
import java.util.concurrent.TimeUnit;
import scala.concurrent.*;
import akka.actor.AbstractActorWithTimers;
import twitter4j.Status;


import scala.concurrent.duration.Duration;



public class TwitterResultActor extends AbstractActorWithTimers {
	
	public final String key ;
	ConfigurationBuilder cb = new ConfigurationBuilder();
	List<ActorRef> userActors = new ArrayList<>();
	List<SearchResults> res = new ArrayList<>();
	int count = 0;
	  private static Object TICK_KEY = "TickKey";
	    private static final class FirstTick {
	    }
	    
	    private static final class Tick {
	    	
	    }
	    
	    static public class RegisterMsg {
	    }
	    
	    @Override
	    public void preStart() {
	        getTimers().startPeriodicTimer("Timer", new Tick(), Duration.create(5, TimeUnit.SECONDS));	        
	    }
    public static Props props(String key) {
        return Props.create(TwitterResultActor.class ,key ) ;
    }
    	        
    public TwitterResultActor (String key) {
  	
        this.key = key;
       
        getTimers().startSingleTimer(TICK_KEY, new FirstTick(), 
                Duration.create(20, TimeUnit.SECONDS));

    }
    
    private final LoggingAdapter log = Logging.getLogger(getContext().system(), this); 
	   
	    @Override	    
	    public Receive createReceive() {
	    	
	        return receiveBuilder()
	          .match(RegisterMsg.class, msg -> userActors.add(sender()))
	          .match(Tick.class, message -> {
	        	  
	        	    System.out.println(HomeController.request.getQueryString("keyword"));
                	Twitter tweet = new Twitter(HomeController.request.getQueryString("keyword"));
                	CompletionStage<QueryResult> SearchResults = tweet.get() ;		

                	res.clear();

                	SearchResults.thenAccept( r -> {
                		if (count == 0){
                			count++ ;
                			System.out.println("Am i called jsut once ??");
                			SearchResults newres = null;
                			int c =0 ;
                			if (c < 9){
                				for (Status s : r.getTweets()){   
                					c++;
                					String TweetHandle = "@" +s.getUser().getScreenName();
                					String Tweets = "\t" + s.getText();               			
                				    newres = new SearchResults(TweetHandle ,Tweets);
                					res.add(newres);   
                				}
                			}
                			MyWebSocketActor.TimeMessage tMsg = new MyWebSocketActor.TimeMessage(res);
                			userActors.forEach(ar -> ar.tell(tMsg, self()));
                		}else{
                			System.out.println("Am i called at all ??");
                			Status s = r.getTweets().get(0);
                			String TweetHandle = "@" +s.getUser().getScreenName();
                			String Tweets = "\t" + s.getText();               			
                			SearchResults newres = new SearchResults(TweetHandle ,Tweets);
                			List<SearchResults> res_temp = new ArrayList<>();
                			res_temp.add(newres);
                			MyWebSocketActor.TimeMessage tMsg = new MyWebSocketActor.TimeMessage(res_temp);
                			userActors.forEach(ar -> ar.tell(tMsg, self()));
                		}
                	}); 
                	               	
/*                	System.out.println("Before tell2" + res.size());
    				MyWebSocketActor.TimeMessage tMsg = new MyWebSocketActor.TimeMessage(res);
            		userActors.forEach(ar -> ar.tell(tMsg, self()));*/
                	                   	
	          })  
	          .build();
	      }

   }
	    

