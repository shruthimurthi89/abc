package twitter;

public class SearchResults {
	
	public SearchResults(String handle, String tweets) {
		super();
		this.handle = handle;
		this.tweets = tweets;
	}
	String handle ;
	String tweets ;
	
	public String getHandle() {
		return handle;
	}
	public void setHandle(String handle) {
		this.handle = handle;
	}
	public String getTweets() {
		return tweets;
	}
	public void setTweets(String tweets) {
		this.tweets = tweets;
	}
	
}
