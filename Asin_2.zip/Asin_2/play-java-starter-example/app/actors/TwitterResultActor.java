package actors;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import akka.actor.AbstractActor;
import akka.actor.Actor;
import akka.actor.ActorRef;
import akka.actor.Props;
import akka.actor.AbstractActor.Receive;
import akka.actor.AbstractActorWithTimers;
import akka.event.LoggingAdapter;
import play.libs.Json;
import twitter.SearchResults;
import twitter.Twitter;
import twitter4j.QueryResult;
import twitter4j.TwitterException;
import twitter4j.conf.ConfigurationBuilder;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import static akka.pattern.PatternsCS.ask;
import java.util.concurrent.TimeUnit;
import scala.concurrent.*;
import akka.actor.AbstractActorWithTimers;
import twitter4j.Status;


import scala.concurrent.duration.Duration;



public class TwitterResultActor extends AbstractActorWithTimers {
	
	public final String key ;
	ConfigurationBuilder cb = new ConfigurationBuilder();
	List<ActorRef> userActors = new ArrayList<>();
	List<SearchResults> res = new ArrayList<>();
	  private static Object TICK_KEY = "TickKey";
	    private static final class FirstTick {
	    }
	    
	    private static final class Tick {
	    }
	    
	    static public class RegisterMsg {
	    }
	    
	    @Override
	    public void preStart() {
	        getTimers().startPeriodicTimer("Timer", new Tick(), Duration.create(5, TimeUnit.SECONDS));
	        
	    }
    public static Props props(String key) {
        return Props.create(TwitterResultActor.class ,key ) ;
    }
    	        
    public TwitterResultActor (String key) {
  	
        this.key = key;
        
        getTimers().startSingleTimer(TICK_KEY, new FirstTick(), 
                Duration.create(1000, TimeUnit.MILLISECONDS));

    }
    
    private final LoggingAdapter log = Logging.getLogger(getContext().system(), this); 
	   
	    @Override
	    
	    public Receive createReceive() {
	        return receiveBuilder()
	          .match(RegisterMsg.class, msg -> userActors.add(sender()))
	          .match(Tick.class, message -> {
	              // do something useful here  
                	Twitter tweet = new Twitter("got");
                	CompletionStage<QueryResult> SearchResults = tweet.get() ;		
                	StringBuilder s1= new StringBuilder("");
                	
                	SearchResults.thenAccept( r -> {
                		
                		for (Status s : r.getTweets()){
                			
                			String TweetHandle = "@" +s.getUser().getScreenName();
                			String Tweets = "\t" + s.getText();                		
                			res.add(new SearchResults(TweetHandle ,Tweets ));	
                		}
                		for(SearchResults s: res) {
                			  s1.append(s.getHandle()+"\n"+s.getTweets()+"\n");
                		}
                	});
                			                	
                	MyWebSocketActor.TimeMessage tMsg = new MyWebSocketActor.TimeMessage(s1.toString());
                	userActors.forEach(ar -> ar.tell(tMsg, self()));
	          })  
	          .build();
	      }

   }
	    

