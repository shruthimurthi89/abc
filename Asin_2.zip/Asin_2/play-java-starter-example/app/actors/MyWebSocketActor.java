package actors;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import akka.NotUsed;
import akka.actor.*;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import akka.stream.Materializer;
import akka.stream.javadsl.Source;
import play.libs.Json;
import twitter.SearchResults;
import twitter4j.QueryResult;
import static akka.pattern.PatternsCS.ask;
import java.util.stream.Collectors;
import akka.util.Timeout;


public class MyWebSocketActor extends AbstractActor {

	List<String> dummy = new ArrayList<>();
	JsonNode SampleJson = null;

	public static Props props(ActorRef out) {
		return Props.create(MyWebSocketActor.class, out);
	}

	private final LoggingAdapter log = Logging.getLogger(getContext().system(), this);

	private final ActorRef out;

	public MyWebSocketActor(ActorRef out) {
		dummy.add("abc");
		dummy.add("bcd");
		SampleJson = Json.toJson(dummy);
		this.out = out;
	}
	  @Override
	    public void preStart() {
	       	context().actorSelection("/user/timeActor/")
	                 .tell(new TwitterResultActor.RegisterMsg(), self());
	    }
	  
	  static public class TimeMessage {
	      public final String time;
	       public TimeMessage(String time) {
	           this.time = time;
	       }
	   }
	  
	   private void sendTime(TimeMessage msg) {	      
	        out.tell(Json.toJson(msg), self());
	   }
	   
	@Override
	public Receive createReceive() {
		return receiveBuilder().match(TimeMessage.class, this::sendTime).build();
	}
}