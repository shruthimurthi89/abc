import controllers.Application;
import controllers.HomeController;
import models.BuildTweetForView;
import static play.mvc.Http.Status.OK;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import akka.actor.ActorSystem;
import akka.testkit.javadsl.TestKit;
import play.api.test.Helpers;
import play.mvc.Result;
import play.twirl.api.Content;
import twitter4j.TwitterException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static play.test.Helpers.contentAsString;

public class FunctionalTest {

	 @Test
	    public void testRejectWebSocket() {
	        TestServer server = testServer(37117);
	        running(server, () -> {
	            try {
	                AsyncHttpClientConfig config = new DefaultAsyncHttpClientConfig.Builder().setMaxRequestRetry(0).build();
	                AsyncHttpClient client = new DefaultAsyncHttpClient(config);
	                WebSocketClient webSocketClient = new WebSocketClient(client);

	                try {
	                    String serverURL = "ws://localhost:37117/ws";
	                    WebSocketClient.LoggingListener listener = new WebSocketClient.LoggingListener(message -> {});
	                    CompletableFuture<WebSocket> completionStage = webSocketClient.call(serverURL, listener);
	                    await().until(completionStage::isDone);
	                    assertThat(completionStage)
	                            .hasFailedWithThrowableThat()
	                            .hasMessageContaining("Invalid Status Code 403");
	                } finally {
	                    client.close();
	                }
	            } catch (Exception e) {
	                fail("Unexpected exception", e);
	            }
	        });
	    }

}
